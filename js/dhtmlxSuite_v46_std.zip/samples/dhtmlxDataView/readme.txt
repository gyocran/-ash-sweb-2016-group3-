To enable DB related samples 
	01_initialization\01_dynamic_loading.html 
	01_initialization\02_dynamic_paging.html
	01_initialization\03_static_loading.html
	01_initialization\04_static_paging.html
	01_initialization\06_paging_custom.html
	06_dataprocessor\01_adding.html 
you need to 
	- have MySQL and PHP 5.x
	- import DB dump from common/dump.sql
	- change DB connection settings in common/config.php
	
	
Next samples 
	08_integration\01_drag_grid.html 
	08_integration\02_drag_tree.html
	08_integration\03_editor.html
	08_integration\04_layout.html
requires external components

Its recommended to run samples through any kind of webserver.
