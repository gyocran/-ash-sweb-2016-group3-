<?php $filter = $_GET["dhx_filter"]; ?>
[
	{ id:"1", Package:"<?php echo $filter["Package"];?>", Version:"<?php echo $filter["Version"];?>", Maintainer:"<?php echo $filter["Maintainer"];?>"}
]